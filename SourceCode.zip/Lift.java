package com.lift;

public class Lift {
    private int floor = 0; 
    private int direction = 0;
    private int sourcefloor = 0;
    private boolean liftAvailable = true;
    private String door = "open";

    private void setDirection(int sourcefloor){
            if(sourcefloor > floor){
                this.direction = 1;
            }
            else if(sourcefloor < floor){
                this.direction = -1;
            }
            else{
                this.direction = 0;
            }
    }
    public boolean isLiftAvailable(){
        return liftAvailable;
    }
    public void call(int sourcefloor, int direction){
        if(liftAvailable){
            setDirection(sourcefloor);
            this.sourcefloor = sourcefloor;
            this.liftAvailable = false;
            this.door = "closed";
        }
    }

    public void request(int requestFloor){
        if(liftAvailable){
            setDirection(requestFloor);
            this.sourcefloor = requestFloor;
            this.liftAvailable = false;
            this.door = "closed";
        }
    }

    public int currentFloorMoniter() {
        return floor;
    }
    
    public int directionArrow() {
        return direction;
    }

    public String doorStatus() {
        return door;
    }

    public void move(){
        this.floor += this.direction;
        if(this.floor == this.sourcefloor){
            this.door = "open";
            this.direction = 0;
            this.liftAvailable = true;
        }
    }
}

