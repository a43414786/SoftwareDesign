package com.lift;
import java.util.ArrayList;

public class LiftSystem {
    private ArrayList<Lift> lift = new ArrayList<Lift>();
    
    public LiftSystem(int liftNum){
        for(int i = 0; i < liftNum; i++){
            lift.add(new Lift());
        }
    }
    

    public void call(int sourcefloor, int direction){
        for(Lift l:this.lift){
            if(l.isLiftAvailable()){
                l.call(sourcefloor, direction);
                break;
            }
        }
    }

    public void request(int requestFloor, int liftidx){
        this.lift.get(liftidx).request(requestFloor);
    }

    public int currentFloorMoniter(int liftidx) {
        return this.lift.get(liftidx).currentFloorMoniter();
    }

    public int directionArrow(int liftidx) {
        return this.lift.get(liftidx).directionArrow();
    }

    public String doorStatus(int liftidx) {
        return this.lift.get(liftidx).doorStatus();
    }

    public void move(){
        for(Lift l:this.lift){
            l.move();
        }
    }

}
