package com.lift;

import static org.junit.Assert.*;

import org.junit.Test;

public class LiftTest 
{
    @Test
    public void case1()
    {
        Lift lift = new Lift();
        lift.call(10, -1);
        for (int i = 0; i < 9; i++) {
            lift.move();
        }
        assertEquals(9, lift.currentFloorMoniter());
        assertEquals(1, lift.directionArrow());
        assertEquals("closed", lift.doorStatus());
        lift.move();
        assertEquals(10, lift.currentFloorMoniter());
        assertEquals(0, lift.directionArrow());
        assertEquals("open", lift.doorStatus());
        lift.request(0);
        for (int i = 0; i < 9; i++) {
            lift.move();
        }
        assertEquals(1, lift.currentFloorMoniter());
        assertEquals(-1, lift.directionArrow());
        assertEquals("closed", lift.doorStatus());
        lift.move();
        assertEquals(0, lift.currentFloorMoniter());
        assertEquals(0, lift.directionArrow());
        assertEquals("open", lift.doorStatus());
    }
    @Test
    public void case2()
    {
        Lift lift = new Lift();
        lift.call(5, -1);
        for (int i = 0; i < 9; i++) {
            lift.move();
        }
        assertEquals(5, lift.currentFloorMoniter());
        assertEquals(0, lift.directionArrow());
        assertEquals("open", lift.doorStatus());
        lift.call(10,1);
        assertEquals(5, lift.currentFloorMoniter());
        assertEquals(1, lift.directionArrow());
        assertEquals("closed", lift.doorStatus());
        lift.request(0);
        assertEquals(5, lift.currentFloorMoniter());
        assertEquals(1, lift.directionArrow());
        assertEquals("closed", lift.doorStatus());
        for (int i = 0; i < 9; i++) {
            lift.move();
        }
        assertEquals(10, lift.currentFloorMoniter());
        assertEquals(0, lift.directionArrow());
        assertEquals("open", lift.doorStatus());
        lift.request(0);
        for (int i = 0; i < 9; i++) {
            lift.move();
        }
        assertEquals(1, lift.currentFloorMoniter());
        assertEquals(-1, lift.directionArrow());
        assertEquals("closed", lift.doorStatus());
        lift.move();
        assertEquals(0, lift.currentFloorMoniter());
        assertEquals(0, lift.directionArrow());
        assertEquals("open", lift.doorStatus());
    }
    @Test
    public void case3()
    {
        Lift lift = new Lift();
        lift.call(5, -1);
        for (int i = 0; i < 9; i++) {
            lift.move();
        }
        assertEquals(5, lift.currentFloorMoniter());
        assertEquals(0, lift.directionArrow());
        assertEquals("open", lift.doorStatus());

        lift.call(10,1);
        lift.call(9, -1);
        lift.call(8, -1);
        lift.call(7, -1);

        assertEquals(5, lift.currentFloorMoniter());
        assertEquals(1, lift.directionArrow());
        assertEquals("closed", lift.doorStatus());
        
        lift.request(0);
        lift.request(1);
        lift.request(2);
        lift.request(3);
        lift.request(4);

        assertEquals(5, lift.currentFloorMoniter());
        assertEquals(1, lift.directionArrow());
        assertEquals("closed", lift.doorStatus());
        
        for (int i = 0; i < 9; i++) {
            lift.move();
        }
        
        assertEquals(10, lift.currentFloorMoniter());
        assertEquals(0, lift.directionArrow());
        assertEquals("open", lift.doorStatus());
        
        lift.request(0);
        for (int i = 0; i < 9; i++) {
            lift.move();
        }
        
        lift.call(10,1);
        lift.call(9, -1);
        lift.call(8, -1);

        assertEquals(1, lift.currentFloorMoniter());
        assertEquals(-1, lift.directionArrow());
        assertEquals("closed", lift.doorStatus());
        
        lift.move();
        
        assertEquals(0, lift.currentFloorMoniter());
        assertEquals(0, lift.directionArrow());
        assertEquals("open", lift.doorStatus());
    }
    @Test
    public void case4()
    {
        LiftSystem liftsys = new LiftSystem(2);
        liftsys.call(5, -1);
        liftsys.call(10, -1);
        for (int i = 0; i < 5; i++) {
            liftsys.move();
        }
        assertEquals(5, liftsys.currentFloorMoniter(0));
        assertEquals(0, liftsys.directionArrow(0));
        assertEquals("open", liftsys.doorStatus(0));
        assertEquals(5, liftsys.currentFloorMoniter(1));
        assertEquals(1, liftsys.directionArrow(1));
        assertEquals("closed", liftsys.doorStatus(1));
        liftsys.request(10, 0);
        for (int i = 0; i < 5; i++) {
            liftsys.move();
        }
        assertEquals(10, liftsys.currentFloorMoniter(0));
        assertEquals(0, liftsys.directionArrow(0));
        assertEquals("open", liftsys.doorStatus(0));
        assertEquals(10, liftsys.currentFloorMoniter(1));
        assertEquals(0, liftsys.directionArrow(1));
        assertEquals("open", liftsys.doorStatus(1));
        liftsys.call(3, -1);
        liftsys.request(0, 1);
        for (int i = 0; i < 7; i++) {
            liftsys.move();
        }
        assertEquals(3, liftsys.currentFloorMoniter(0));
        assertEquals(0, liftsys.directionArrow(0));
        assertEquals("open", liftsys.doorStatus(0));
        assertEquals(3, liftsys.currentFloorMoniter(1));
        assertEquals(-1, liftsys.directionArrow(1));
        assertEquals("closed", liftsys.doorStatus(1));
        liftsys.request(0, 0);
        for (int i = 0; i < 3; i++) {   
            liftsys.move();
        }
        assertEquals(0, liftsys.currentFloorMoniter(0));
        assertEquals(0, liftsys.directionArrow(0));
        assertEquals("open", liftsys.doorStatus(0));
        assertEquals(0, liftsys.currentFloorMoniter(1));
        assertEquals(0, liftsys.directionArrow(1));
        assertEquals("open", liftsys.doorStatus(1));
    }
    @Test
    public void case5()
    {
        LiftSystem liftsys = new LiftSystem(5);
        liftsys.call(1, -1);
        liftsys.call(2, 1);
        liftsys.call(3, 1);
        liftsys.call(4, 1);
        liftsys.call(5, -1);
        for (int i = 0; i < 5; i++) {
            liftsys.move();
        }
        assertEquals(1, liftsys.currentFloorMoniter(0));
        assertEquals(0, liftsys.directionArrow(0));
        assertEquals("open", liftsys.doorStatus(0));
        assertEquals(2, liftsys.currentFloorMoniter(1));
        assertEquals(0, liftsys.directionArrow(1));
        assertEquals("open", liftsys.doorStatus(1));
        assertEquals(3, liftsys.currentFloorMoniter(2));
        assertEquals(0, liftsys.directionArrow(2));
        assertEquals("open", liftsys.doorStatus(2));
        assertEquals(4, liftsys.currentFloorMoniter(3));
        assertEquals(0, liftsys.directionArrow(3));
        assertEquals("open", liftsys.doorStatus(3));
        assertEquals(5, liftsys.currentFloorMoniter(4));
        assertEquals(0, liftsys.directionArrow(4));
        assertEquals("open", liftsys.doorStatus(4));
        
        liftsys.request(10, 0);
        liftsys.request(9, 1);
        liftsys.request(8, 2);
        liftsys.request(7, 3);
        liftsys.request(6, 4);
        liftsys.move();
        
        assertEquals(2, liftsys.currentFloorMoniter(0));
        assertEquals(1, liftsys.directionArrow(0));
        assertEquals("closed", liftsys.doorStatus(0));
        assertEquals(3, liftsys.currentFloorMoniter(1));
        assertEquals(1, liftsys.directionArrow(1));
        assertEquals("closed", liftsys.doorStatus(1));
        assertEquals(4, liftsys.currentFloorMoniter(2));
        assertEquals(1, liftsys.directionArrow(2));
        assertEquals("closed", liftsys.doorStatus(2));
        assertEquals(5, liftsys.currentFloorMoniter(3));
        assertEquals(1, liftsys.directionArrow(3));
        assertEquals("closed", liftsys.doorStatus(3));
        assertEquals(6, liftsys.currentFloorMoniter(4));
        assertEquals(0, liftsys.directionArrow(4));
        assertEquals("open", liftsys.doorStatus(4));
        
        for (int i = 0; i < 3; i++) {
            liftsys.move();
        }
        
        assertEquals(5, liftsys.currentFloorMoniter(0));
        assertEquals(1, liftsys.directionArrow(0));
        assertEquals("closed", liftsys.doorStatus(0));
        assertEquals(6, liftsys.currentFloorMoniter(1));
        assertEquals(1, liftsys.directionArrow(1));
        assertEquals("closed", liftsys.doorStatus(1));
        assertEquals(7, liftsys.currentFloorMoniter(2));
        assertEquals(1, liftsys.directionArrow(2));
        assertEquals("closed", liftsys.doorStatus(2));
        assertEquals(7, liftsys.currentFloorMoniter(3));
        assertEquals(0, liftsys.directionArrow(3));
        assertEquals("open", liftsys.doorStatus(3));
        assertEquals(6, liftsys.currentFloorMoniter(4));
        assertEquals(0, liftsys.directionArrow(4));
        assertEquals("open", liftsys.doorStatus(4));
        
        for (int i = 0; i < 5; i++) {
            liftsys.move();
        }

        assertEquals(10, liftsys.currentFloorMoniter(0));
        assertEquals(0, liftsys.directionArrow(0));
        assertEquals("open", liftsys.doorStatus(0));
        assertEquals(9, liftsys.currentFloorMoniter(1));
        assertEquals(0, liftsys.directionArrow(1));
        assertEquals("open", liftsys.doorStatus(1));
        assertEquals(8, liftsys.currentFloorMoniter(2));
        assertEquals(0, liftsys.directionArrow(2));
        assertEquals("open", liftsys.doorStatus(2));
        assertEquals(7, liftsys.currentFloorMoniter(3));
        assertEquals(0, liftsys.directionArrow(3));
        assertEquals("open", liftsys.doorStatus(3));
        assertEquals(6, liftsys.currentFloorMoniter(4));
        assertEquals(0, liftsys.directionArrow(4));
        assertEquals("open", liftsys.doorStatus(4));
    }
}
